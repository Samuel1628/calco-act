
const num = (v, d = 2) => (Math.round(v * 10 ** d + 1e-9) / 10 ** d).toFixed(d);
const arriba = (v) => Math.ceil(Number(v.toFixed(6)));
const miles = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
const fila = (material, cantidad) => ({ material, cantidad });


const calculadores = {
  muro(p, k) {
    const esp = p.get("espesor");
    const largo = parseFloat(p.get("largo"));
    const alto = parseFloat(p.get("alto"));
    const c = k.muro[esp];
    const area = largo * alto;
    return {
      resumen: `MURO ${esp.toUpperCase()} · ${num(largo)} × ${num(alto)} m = ${num(area)} m²`,
      filas: [
        fila("Cemento", num(area * c.cemento_kg_m2, 1) + " kg"),
        fila("Arena", num(area * c.arena_m3_m2) + " m³"),
        fila("Ladrillos", miles(arriba(area * c.ladrillos_u_m2)) + " u"),
      ],
    };
  },

  viga(p, k) {
    const sec = p.get("seccion");
    const largo = parseFloat(p.get("largo"));
    const cant = parseInt(p.get("cantidad"), 10);
    const c = k.viga;
    const vol = c.secciones_m2[sec] * largo * cant;
    return {
      resumen: `VIGA ${sec.replace("x", "×").toUpperCase()} · LARGO ${num(largo)} m × ${cant} UNID. = ${num(vol)} m³`,
      filas: [
        fila("Cemento", num(vol * c.cemento_kg_m3, 1) + " kg"),
        fila("Arena", num(vol * c.arena_m3_m3) + " m³"),
        fila("Piedra Partida", num(vol * c.piedra_m3_m3) + " m³"),
        fila("Hierro (Acero)", num(vol * c.hierro_kg_m3, 1) + " kg"),
      ],
    };
  },

  columna(p, k) {
    const sec = p.get("seccion");
    const alto = parseFloat(p.get("alto"));
    const cant = parseInt(p.get("cantidad"), 10);
    const c = k.columna;
    const vol = c.secciones_m2[sec] * alto * cant;
    return {
      resumen: `COLUMNAS ${sec.replace("x", "×").toUpperCase()} · ALTO ${num(alto)} m × ${cant} UNID. = ${num(vol)} m³`,
      filas: [
        fila("Cemento", num(vol * c.cemento_kg_m3, 1) + " kg"),
        fila("Arena", num(vol * c.arena_m3_m3) + " m³"),
        fila("Piedra Partida", num(vol * c.piedra_m3_m3) + " m³"),
        fila("Hierro 12mm", num(vol * c.hierro_kg_m3, 1) + " kg"),
        fila("Estribos 6mm", miles(arriba(alto * cant * c.estribos_u_m)) + " u"),
      ],
    };
  },

  contrapiso(p, k) {
    const esp = p.get("espesor");
    const largo = parseFloat(p.get("largo"));
    const ancho = parseFloat(p.get("ancho"));
    const c = k.contrapiso;
    const vol = (parseFloat(esp) / 100) * largo * ancho;
    return {
      resumen: `CONTRAPISO ${esp.toUpperCase()} · ${num(largo)} × ${num(ancho)} m = ${num(vol)} m³`,
      filas: [
        fila("Cemento", num(vol * c.cemento_kg_m3, 1) + " kg"),
        fila("Cal Hidratada", num(vol * c.cal_kg_m3, 1) + " kg"),
        fila("Arena", num(vol * c.arena_m3_m3) + " m³"),
        fila("Cascote / Piedra", num(vol * c.cascote_m3_m3) + " m³"),
      ],
    };
  },

  techo(p, k) {
    const tipo = p.get("tipo");
    const largo = parseFloat(p.get("largo"));
    const ancho = parseFloat(p.get("ancho"));
    const c = k.techo[tipo];
    const area = largo * ancho;
    const resumen = `TECHO ${c.etiqueta} · ${num(largo)} × ${num(ancho)} m = ${num(area)} m²`;

    if (tipo === "Losa Viguetas") {
      return {
        resumen,
        filas: [
          fila("Viguetas Pretensadas", `${arriba(ancho / c.separacion_viguetas_m)} líneas (${num(largo)}m)`),
          fila("Bovedillas", miles(arriba(area * c.bovedillas_u_m2)) + " u"),
          fila("Malla de Hierro", arriba(area * c.malla_m2_m2) + " m²"),
          fila("Cemento (Capa Compresión)", arriba(area * c.cemento_kg_m2) + " kg"),
        ],
      };
    }
    return {
      resumen,
      filas: [
        fila(`Chapas (+${c.traslape * 100}% traslape)`, num(area * (1 + c.traslape)) + " m²"),
        fila("Correas", `${arriba(ancho / c.separacion_correas_m) + 1} líneas (${num(largo)}m)`),
        fila("Tornillos autoperforantes", miles(arriba(area * c.tornillos_u_m2)) + " u"),
      ],
    };
  },

  piso(p, k) {
    const tipo = p.get("tipo");
    const largo = parseFloat(p.get("largo"));
    const ancho = parseFloat(p.get("ancho"));
    const c = k.piso[tipo];
    const area = largo * ancho;
    return {
      resumen: `PISO ${tipo.toUpperCase()} · ${num(largo)} × ${num(ancho)} m (+${k.piso.desperdicio * 100}% desperdicio)`,
      filas: [
        fila(`Placas (${tipo})`, num(area * (1 + k.piso.desperdicio)) + " m²"),
        fila("Mezcla Adhesiva / Pegamento", arriba(area * c.adhesivo_kg_m2) + " kg"),
        fila("Pastina / Fraguador", num(area * c.pastina_kg_m2, 1) + " kg"),
      ],
    };
  },

  pintura(p, k) {
    const sup = p.get("superficie");
    const manos = parseInt(p.get("manos"), 10);
    const largo = parseFloat(p.get("largo"));
    const alto = parseFloat(p.get("alto"));
    const c = k.pintura[sup];
    const area = largo * alto;
    return {
      resumen: `PINTURA ${sup.toUpperCase()} · ${num(largo)} × ${num(alto)} m (${manos} ${manos === 1 ? "MANO" : "MANOS"}) = ${num(area)} m²`,
      filas: [
        fila(c.etiqueta, num((area * manos) / c.rendimiento_m2_por_L, 1) + " L"),
        fila("Fijador / Sellador", num(area * k.pintura.fijador_L_m2, 1) + " L"),
        fila("Cinta de Enmascarar", Math.max(1, arriba(area / k.pintura.cinta_rollo_cada_m2)) + " rollo"),
      ],
    };
  },
};

async function mostrarResultado() {
  const resumen = document.querySelector(".caja-resumen");
  const tbody = document.querySelector(".tabla-resultado tbody");

  const coincide = location.pathname.match(/resultado-([a-z]+)\.html/);
  const nombre = coincide && coincide[1];
  const params = new URLSearchParams(location.search);

  try {
    if (!calculadores[nombre]) throw new Error("Calculo desconocido");
    if (![...params.keys()].length) throw new Error("Faltan datos");

    const res = await fetch("materiales.json");
    if (!res.ok) throw new Error("No se pudo cargar materiales.json");
    const coeficientes = await res.json();

    const calculo = calculadores[nombre](params, coeficientes);
    const { resumen: texto, filas } = calculo;
    resumen.textContent = texto;

    // Mostrar los resultados en la tabla HTML.
    tbody.innerHTML = filas.map(item =>
      `<tr><td>${item.material}</td><td class="alinear-derecha">${item.cantidad}</td></tr>`
    ).join("");

    // Construir un objeto JSON con los datos ingresados y los resultados.
    const reporteJSON = {
      proyecto: "CALCO",
      calculo: nombre,
      fecha: new Date().toISOString(),
      parametros_ingresados: Object.fromEntries(params.entries()),
      resumen: texto,
      resultados: filas.map(item => ({
        material: item.material,
        cantidad: item.cantidad
      }))
    };

    // Crear una sección visible para que el profesor pueda revisar el JSON.
    let panelJSON = document.getElementById("panel-json-resultados");
    if (!panelJSON) {
      panelJSON = document.createElement("section");
      panelJSON.id = "panel-json-resultados";
      panelJSON.style.cssText = "margin-top:24px;padding:18px;border:1px solid #d7dee8;border-radius:12px;background:#f8fafc;color:#172033;max-width:100%;";
      panelJSON.innerHTML = `
        <h2 style="font-size:18px;margin:0 0 8px;">Datos del cálculo en JSON</h2>
        <p style="font-size:13px;margin:0 0 12px;color:#526078;">Este objeto contiene los parámetros ingresados y los resultados generados por CALCO.</p>
        <pre id="contenido-json-resultados" style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:420px;overflow:auto;padding:14px;background:#111827;color:#d1fae5;border-radius:8px;font-size:12px;"></pre>
        <button id="descargar-json-resultados" type="button" style="margin-top:12px;padding:10px 14px;border:0;border-radius:7px;background:#173b68;color:white;cursor:pointer;font-weight:600;">Descargar JSON</button>
      `;
      const contenedor = document.querySelector(".caja-contenido") || document.querySelector("main") || document.body;
      contenedor.appendChild(panelJSON);
    }

    const jsonFormateado = JSON.stringify(reporteJSON, null, 2);
    panelJSON.querySelector("#contenido-json-resultados").textContent = jsonFormateado;
    panelJSON.querySelector("#descargar-json-resultados").onclick = () => {
      const archivo = new Blob([jsonFormateado], { type: "application/json" });
      const url = URL.createObjectURL(archivo);
      const enlace = document.createElement("a");
      enlace.href = url;
      enlace.download = `calco-${nombre}-resultado.json`;
      enlace.click();
      URL.revokeObjectURL(url);
    };
  } catch (err) {
    console.error(err);
    const esFetch = err instanceof TypeError; 
    resumen.textContent = esFetch
      ? "No se pudo cargar materiales.json. Abre el proyecto con un servidor local (Live Server) o GitHub Pages."
      : "No hay datos para calcular. Vuelve al formulario y pulsa CALCULAR.";
    tbody.innerHTML = "";
  }
}

mostrarResultado();
