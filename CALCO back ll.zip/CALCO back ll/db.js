// db.js - Conexión y gestión de la Base de Datos SQLite (nativa de Node.js)
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');
const bcrypt = require('bcryptjs');

const dbPath = path.join(__dirname, 'database.sqlite');
const db = new DatabaseSync(dbPath);

// Inicializar tablas
function inicializarBD() {
    // Crear tabla de usuarios
    db.exec(`
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            rol TEXT DEFAULT 'Estudiante',
            fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    `);

    // Comprobar si ya existen usuarios por defecto
    const consulta = db.prepare('SELECT COUNT(*) AS total FROM usuarios');
    const resultado = consulta.get();

    if (resultado.total === 0) {
        console.log('📦 Inicializando usuarios por defecto en la base de datos...');
        const insertar = db.prepare(`
            INSERT INTO usuarios (nombre, email, password, rol)
            VALUES (?, ?, ?, ?)
        `);

        // Contraseña por defecto: 12345678
        const passHash1 = bcrypt.hashSync('12345678', 10);
        insertar.run('Samuel Giraldo Villanueva', 'samuel@calco.com', passHash1, 'Administrador');

        const passHash2 = bcrypt.hashSync('12345678', 10);
        insertar.run('Usuario Demo', 'usuario@calco.com', passHash2, 'Estudiante');

        console.log('✅ Usuarios iniciales creados:');
        console.log('   - samuel@calco.com / 12345678 (Administrador)');
        console.log('   - usuario@calco.com / 12345678 (Estudiante)');
    }
}

// Buscar usuario por correo electrónico
function obtenerUsuarioPorEmail(email) {
    const consulta = db.prepare('SELECT * FROM usuarios WHERE LOWER(email) = LOWER(?)');
    return consulta.get(email);
}

// Obtener todos los usuarios (sin contraseñas)
function obtenerTodosLosUsuarios() {
    const consulta = db.prepare('SELECT id, nombre, email, rol, fecha_registro FROM usuarios ORDER BY id DESC');
    return consulta.all();
}

// Registrar nuevo usuario
function registrarUsuario({ nombre, email, password, rol = 'Estudiante' }) {
    const passHash = bcrypt.hashSync(password, 10);
    const insertar = db.prepare(`
        INSERT INTO usuarios (nombre, email, password, rol)
        VALUES (?, ?, ?, ?)
    `);
    
    const info = insertar.run(nombre, email, passHash, rol);
    const consulta = db.prepare('SELECT id, nombre, email, rol, fecha_registro FROM usuarios WHERE id = ?');
    return consulta.get(info.lastInsertRowid);
}

// Validar credenciales (login)
function validarCredenciales(email, password) {
    const usuario = obtenerUsuarioPorEmail(email);
    if (!usuario) {
        return { valido: false, razon: 'El correo electrónico no está registrado.' };
    }

    // Comprobación con bcrypt o texto plano (por compatibilidad)
    let passwordValida = false;
    try {
        passwordValida = bcrypt.compareSync(password, usuario.password);
    } catch {
        passwordValida = false;
    }

    if (!passwordValida && usuario.password === password) {
        passwordValida = true;
    }

    if (!passwordValida) {
        return { valido: false, razon: 'La contraseña es incorrecta.' };
    }

    // Retornar datos del usuario sin exponer la contraseña
    const { password: _, ...datosSeguros } = usuario;
    return { valido: true, usuario: datosSeguros };
}

inicializarBD();

module.exports = {
    db,
    obtenerUsuarioPorEmail,
    obtenerTodosLosUsuarios,
    registrarUsuario,
    validarCredenciales
};
