# CALCO - Integración Backend con Node.js, Base de Datos y JSON

Este proyecto integra un servidor backend en **Node.js** con **Express** y una base de datos **SQLite** (usando el módulo nativo `node:sqlite`), permitiendo autenticación de usuarios, persistencia en base de datos y respuestas en formato **JSON**.

---

## 🚀 Cómo Iniciar el Servidor

1. Abre una terminal en la carpeta raíz del proyecto (`CALCO back ll`).
2. Ejecuta:
   ```bash
   npm start
   ```
   O en modo desarrollo con recarga automática:
   ```bash
   npm run dev
   ```
3. Abre tu navegador en:
   **[http://localhost:3000/login.html](http://localhost:3000/login.html)**

---

## 🗄️ Base de Datos (`database.sqlite`)

La base de datos se crea y gestiona automáticamente en [`db.js`](file:///c:/Users/SAMUEL%20GIRALDO/Downloads/CALCO%20back%20ll/db.js).

### Tabla `usuarios`:
- `id`: Entero autoincremental (Clave primaria).
- `nombre`: Nombre completo del usuario.
- `email`: Correo electrónico único.
- `password`: Contraseña cifrada de forma segura con **bcryptjs**.
- `rol`: Rol del usuario (`Administrador`, `Estudiante`, etc.).
- `fecha_registro`: Fecha y hora de creación automática.

### Usuarios de prueba predeterminados:
| Correo | Contraseña | Rol |
| :--- | :--- | :--- |
| `samuel@calco.com` | `12345678` | Administrador |
| `usuario@calco.com` | `12345678` | Estudiante |

*(También puedes registrar nuevos usuarios desde [`registro.html`](file:///c:/Users/SAMUEL%20GIRALDO/Downloads/CALCO%20back%20ll/CALCO/registro.html)).*

---

## 📡 Endpoints de la API (Respuestas en JSON)

### 1. Iniciar Sesión (Login)
- **Ruta:** `POST /api/login` (o `POST /login`)
- **Body (JSON):**
  ```json
  {
    "email": "samuel@calco.com",
    "password": "12345678"
  }
  ```
- **Respuesta Exitosa (200 OK):**
  ```json
  {
    "status": "success",
    "message": "¡Inicio de sesión exitoso!",
    "usuario": {
      "id": 1,
      "nombre": "Samuel Giraldo Villanueva",
      "email": "samuel@calco.com",
      "rol": "Administrador",
      "fecha_registro": "2026-10-27 22:01:18"
    },
    "timestamp": "2026-10-27T22:07:22.612Z"
  }
  ```
- **Respuesta de Error (401 Unauthorized):**
  ```json
  {
    "status": "error",
    "message": "Credenciales inválidas.",
    "detalles": "La contraseña es incorrecta.",
    "timestamp": "2026-10-27T22:07:22.668Z"
  }
  ```

---

### 2. Registrar Nuevo Usuario
- **Ruta:** `POST /api/registro`
- **Body (JSON):**
  ```json
  {
    "nombre": "Nuevo Usuario",
    "email": "nuevo@calco.com",
    "password": "mi_clave_segura_8"
  }
  ```
- **Respuesta (201 Created):** Retorna el nuevo registro en JSON.

---

### 3. Consultar Todos los Usuarios en BD
- **Ruta:** `GET /api/usuarios`
- Retorna la lista completa de usuarios registrados en formato JSON.

---

### 4. Estado del Servidor
- **Ruta:** `GET /api/estado`
- Retorna el estado en línea y motor de base de datos en JSON.

---

## 🖥️ Interfaz Visual con Visor JSON
- Al presionar **"Entrar"** en el login, los datos enviados son consultados en la base de datos y la respuesta del servidor se proyecta en pantalla dentro de un **Visor de Código JSON** con resaltado, botón para copiar y opción de continuar al menú.
