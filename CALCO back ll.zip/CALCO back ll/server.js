// server.js - Servidor Node.js con Express y Base de Datos
const express = require('express');
const cors = require('cors');
const path = require('node:path');
const db = require('./db.js');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir archivos estáticos de la carpeta CALCO
app.use(express.static(path.join(__dirname, 'CALCO')));

// Redirección de la raíz al login
app.get('/', (req, res) => {
    res.redirect('/login.html');
});

// Endpoint de Login (Soporta JSON y formularios estándar)
app.post(['/api/login', '/login'], (req, res) => {
    const email = req.body.email || req.body.usuario;
    const password = req.body.password || req.body.contrasena;

    if (!email || !password) {
        return res.status(400).json({
            status: 'error',
            message: 'Faltan campos obligatorios: email y password son requeridos.',
            timestamp: new Date().toISOString()
        });
    }

    const resultado = db.validarCredenciales(email.trim(), password);

    if (!resultado.valido) {
        return res.status(401).json({
            status: 'error',
            message: 'Credenciales inválidas.',
            detalles: resultado.razon,
            timestamp: new Date().toISOString()
        });
    }

    // Respuesta exitosa con los datos del usuario en formato JSON
    return res.status(200).json({
        status: 'success',
        message: '¡Inicio de sesión exitoso!',
        usuario: resultado.usuario,
        timestamp: new Date().toISOString()
    });
});

// Endpoint de Registro
app.post(['/api/registro', '/registro'], (req, res) => {
    const { nombre, email, password, rol } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            status: 'error',
            message: 'Email y contraseña son obligatorios.',
            timestamp: new Date().toISOString()
        });
    }

    const existe = db.obtenerUsuarioPorEmail(email.trim());
    if (existe) {
        return res.status(409).json({
            status: 'error',
            message: 'El correo electrónico ya se encuentra registrado.',
            timestamp: new Date().toISOString()
        });
    }

    try {
        const nuevoUsuario = db.registrarUsuario({
            nombre: nombre ? nombre.trim() : email.split('@')[0],
            email: email.trim(),
            password: password,
            rol: rol || 'Estudiante'
        });

        return res.status(201).json({
            status: 'success',
            message: 'Usuario registrado exitosamente en la base de datos.',
            usuario: nuevoUsuario,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        return res.status(500).json({
            status: 'error',
            message: 'Error al registrar el usuario en la base de datos.',
            error: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// Endpoint para consultar todos los usuarios de la base de datos en JSON
app.get('/api/usuarios', (req, res) => {
    const usuarios = db.obtenerTodosLosUsuarios();
    res.json({
        status: 'success',
        total: usuarios.length,
        usuarios: usuarios,
        timestamp: new Date().toISOString()
    });
});

// Endpoint de información del sistema y base de datos
app.get('/api/estado', (req, res) => {
    const usuarios = db.obtenerTodosLosUsuarios();
    res.json({
        status: 'online',
        servidor: 'Node.js Express',
        base_de_datos: 'SQLite (node:sqlite nativo)',
        total_usuarios_registrados: usuarios.length,
        timestamp: new Date().toISOString()
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(`🚀 Servidor CALCO corriendo en http://localhost:${PORT}`);
    console.log(`📁 Archivos estáticos servidos desde: /CALCO`);
    console.log(`🔐 Endpoint Login: POST http://localhost:${PORT}/api/login`);
    console.log(`📝 Endpoint Registro: POST http://localhost:${PORT}/api/registro`);
    console.log(`👥 Endpoint Usuarios: GET http://localhost:${PORT}/api/usuarios`);
    console.log(`====================================================`);
});
